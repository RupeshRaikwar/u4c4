
const express = require("express");

const connect = require("./configs/db");

const app = express();

const userController = require("./controllers/user.controller");

const todoController = require("./controllers/todo.controllers");

app.use(express.json());

app.use("/users", userController);
app.post("/register",register);
app.post("login",login);
app.post("/todo",todoController);


app.listen("4466", async(req,res)=>{
     try {
         await connect();

         console.log("listning to port 4466");

     } catch (error) {
         console.log(error);
     }
});