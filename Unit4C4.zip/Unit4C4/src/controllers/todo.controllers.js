const express = require("express");
const res = require("express/lib/response");

const Todo = require("../model/todo.model");

const router = express.Router();

router.post("", async()=>{

    try {
        const todo = await Todo.create(req.body);

        return res.status(200).send(todo);

    } catch (error) {
        return res.status(500).send(error);
    }
});

router.get("", async()=>{

    try {
        const todo = await Todo.find().lean().exec();

        return res.status(200).send(todo);

    } catch (error) {
        return res.status(500).send(error);
    }
});


router.get("/:id", async()=>{

    try {
        const todo = await Todo.findById(req.params.id).lean().exec();

        return res.status(200).send(todo);

    } catch (error) {
        return res.status(500).send(error);
    }
});

router.patch("/:id", async()=>{

    try {
        const todo = await Todo.findByIdAndUpdate(req.params.id,req.body,{new:true}).lean().exec();

        return res.status(200).send(todo);

    } catch (error) {
        return res.status(500).send(error);
    }
});

router.delete("/:id", async()=>{

    try {
        const todo = await Todo.findByIdAndDelete().lean().exec();

        return res.status(200).send(todo);

    } catch (error) {
        return res.status(500).send(error);
    }
});